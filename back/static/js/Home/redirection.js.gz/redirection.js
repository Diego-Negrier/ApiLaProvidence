function redirectToCatalog() {
    window.location.href = '/catalogue'; // Redirection vers l'URL du catalogue
}
function redirectToCommande() {
    window.location.href = '/commandes'; // Redirection vers l'URL du catalogue
}
function redirectToFournisseur() {
    window.location.href = '/fournisseur'; // Redirection vers l'URL du catalogue
}
